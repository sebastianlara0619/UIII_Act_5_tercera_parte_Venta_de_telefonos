from django.shortcuts import render, redirect, get_object_or_404
from .models import Vendedor, Proveedor, Producto, Venta, Producto_Proveedor
from django.utils import timezone

# --- SECCIÓN: INICIO ---
def inicio_ventas(request):
    """Página principal del sistema."""
    return render(request, 'inicio.html')

# --- SECCIÓN: VENDEDORES ---
def ver_vendedores(request):
    """Lista de todo el personal de ventas."""
    vendedores = Vendedor.objects.all()
    return render(request, 'vendedor/ver_vendedores.html', {'vendedores': vendedores})

def agregar_vendedor(request):
    """Registra un nuevo vendedor en la tienda."""
    if request.method == 'POST':
        Vendedor.objects.create(
            nombre=request.POST.get('nombre'),
            apellido=request.POST.get('apellido'),
            cargo=request.POST.get('cargo'),
            telefono=request.POST.get('telefono'),
            email=request.POST.get('email'),
            fecha_contratacion=request.POST.get('fecha_contratacion'),
            salario=request.POST.get('salario')
        )
        return redirect('ver_vendedores')
    return render(request, 'vendedor/agregar_vendedor.html')

def actualizar_vendedor(request, vendedor_id):
    """Modifica los datos de un vendedor existente."""
    vendedor = get_object_or_404(Vendedor, id=vendedor_id)
    if request.method == 'POST':
        vendedor.nombre = request.POST.get('nombre')
        vendedor.apellido = request.POST.get('apellido')
        vendedor.cargo = request.POST.get('cargo')
        vendedor.telefono = request.POST.get('telefono')
        vendedor.email = request.POST.get('email')
        vendedor.fecha_contratacion = request.POST.get('fecha_contratacion')
        vendedor.salario = request.POST.get('salario')
        vendedor.save()
        return redirect('ver_vendedores')
    return render(request, 'vendedor/actualizar_vendedor.html', {'vendedor': vendedor})

def borrar_vendedor(request, vendedor_id):
    """Elimina a un vendedor."""
    vendedor = get_object_or_404(Vendedor, id=vendedor_id)
    if request.method == 'POST':
        vendedor.delete()
        return redirect('ver_vendedores')
    return render(request, 'vendedor/borrar_vendedor.html', {'vendedor': vendedor})

# --- SECCIÓN: PROVEEDORES ---
def ver_proveedores(request):
    """Muestra el directorio de proveedores registrados."""
    proveedores = Proveedor.objects.all().order_by('-id') 
    return render(request, 'proveedor/ver_proveedor.html', {'proveedores': proveedores})

def agregar_proveedor(request):
    """Registra una nueva empresa proveedora."""
    if request.method == 'POST':
        try:
            Proveedor.objects.create(
                nombre=request.POST.get('nombre'),
                empresa=request.POST.get('empresa'),
                telefono=request.POST.get('telefono'),
                email=request.POST.get('email'),
                direccion=request.POST.get('direccion'),
                ciudad=request.POST.get('ciudad')
            )
            return redirect('ver_proveedores')
        except Exception as e:
            print(f"ERROR AL GUARDAR PROVEEDOR: {e}")
    return render(request, 'proveedor/agregar_proveedor.html')

def actualizar_proveedor(request, proveedor_id):
    """Modifica los datos de un proveedor."""
    proveedor = get_object_or_404(Proveedor, id=proveedor_id)
    if request.method == 'POST':
        proveedor.nombre = request.POST.get('nombre')
        proveedor.empresa = request.POST.get('empresa')
        proveedor.telefono = request.POST.get('telefono')
        proveedor.email = request.POST.get('email')
        proveedor.direccion = request.POST.get('direccion')
        proveedor.ciudad = request.POST.get('ciudad')
        proveedor.save()
        return redirect('ver_proveedores')
    return render(request, 'proveedor/actualizar_proveedor.html', {'proveedor': proveedor})

def borrar_proveedor(request, proveedor_id):
    """Elimina un proveedor."""
    proveedor = get_object_or_404(Proveedor, id=proveedor_id)
    if request.method == 'POST':
        proveedor.delete()
        return redirect('ver_proveedores')
    return render(request, 'proveedor/borrar_proveedor.html', {'proveedor': proveedor})

# --- SECCIÓN: INVENTARIO / PRODUCTOS ---

def ver_productos(request):
    """Muestra el stock de teléfonos y su proveedor."""
    productos = Producto.objects.all().prefetch_related('producto_proveedores__proveedor')
    return render(request, 'inventario/ver_productos.html', {'productos': productos})

def agregar_producto(request):
    """Registra un celular y crea su relación obligatoria con el proveedor."""
    if request.method == 'POST':
        try:
            # 1. Crear el Producto principal
            nuevo_celular = Producto.objects.create(
                nombre=request.POST.get('nombre'),
                marca=request.POST.get('marca'),
                modelo=request.POST.get('modelo'),
                precio_venta=request.POST.get('precio_venta'),
                stock=request.POST.get('stock'),
                descripcion=request.POST.get('descripcion')
            )
            
            # 2. Crear la relación con el Proveedor (Producto_Proveedor)
            # Esto es lo que hacía que antes "no jalara" si se olvidaba
            Producto_Proveedor.objects.create(
                producto=nuevo_celular,
                proveedor_id=request.POST.get('proveedor_id'),
                precio_compra=request.POST.get('precio_compra'),
                cantidad_disponible=request.POST.get('stock'),
                garantia_meses=request.POST.get('garantia', 12)
            )
            
            print(f"✅ PRODUCTO Y RELACIÓN CREADOS: {nuevo_celular.nombre}")
            return redirect('ver_productos')
        except Exception as e:
            print(f"❌ Error al agregar: {e}")

    proveedores = Proveedor.objects.all()
    return render(request, 'inventario/agregar_producto.html', {'proveedores': proveedores})

def actualizar_producto(request, producto_id):
    """Modifica datos del teléfono y su relación comercial."""
    producto = get_object_or_404(Producto, id=producto_id)
    rel_proveedor = producto.producto_proveedores.first() 
    
    if request.method == 'POST':
        # Actualizar Producto
        producto.nombre = request.POST.get('nombre')
        producto.marca = request.POST.get('marca')
        producto.modelo = request.POST.get('modelo')
        producto.precio_venta = request.POST.get('precio_venta')
        producto.stock = request.POST.get('stock')
        producto.save() 
        
        # Actualizar Relación (si existe)
        if rel_proveedor:
            rel_proveedor.proveedor_id = request.POST.get('proveedor_id')
            rel_proveedor.precio_compra = request.POST.get('precio_compra')
            rel_proveedor.garantia_meses = request.POST.get('garantia')
            rel_proveedor.save() 
            
        return redirect('ver_productos')
    
    proveedores = Proveedor.objects.all()
    return render(request, 'inventario/actualizar_producto.html', {
        'producto': producto, 
        'rel_proveedor': rel_proveedor,
        'proveedores': proveedores
    })

def borrar_producto(request, producto_id):
    """Elimina un producto."""
    producto = get_object_or_404(Producto, id=producto_id)
    if request.method == 'POST':
        producto.delete()
        return redirect('ver_productos')
    return render(request, 'inventario/borrar_producto.html', {'producto': producto})
